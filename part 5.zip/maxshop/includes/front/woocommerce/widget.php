<?php

/*
*	Product serarch
*/

class Product_search extends WP_Widget{
	
	// to register widget and construct name and widget classes.
	Public function __construct(){
		parent::__construct('Product_search','Maxshop Product search', array(
			'classname'=>'widget_search',
			'description' => 'Maxshop Product Ajax Search',
		
		));
		
	}
	
	// create widget form
	
	function form($instance){
	
	$title = $instance['title'];
	$per_page_search = $instance['per_page_search'];
	
	?>
		
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>">Title:
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title');  ?>" type="text" value="<?php echo $title; ?>">
			</label>
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('per_page_search'); ?>">Max search Result:
			
				<input class="widefat" id="<?php echo $this->get_field_id('per_page_search'); ?>" name="<?php echo $this->get_field_name('per_page_search');  ?>" type="number" value="<?php echo $per_page_search; ?>">
			</label>
		</p>
		
		
		
	<?php	
		
	}
	// to show result in fornt end;
	function widget($args, $instance ){
		
		$title = ($instance['title']) ? $instance['title'] : 'Serach';
		$per_page_search = $instance['per_page_search'] ? $instance['per_page_search'] : 5 ;
		$widget_content ='<div class="input-group">
							<input type="text" id="search_input_box" class="form-control" placeholder="Search You Wants. . .">
							<input type="hidden" id="serach_per_page" value="'.$per_page_search.'" >
							<span class="input-group-btn">
								<button class="btn btn-search" title="Search" type="button"><i class="icon icon-Search"></i></button>
							</span>
						 </div>
						 <div class="search_result_warp">
						 	
						 </div>
						 
						 
						 ';
	echo $args['before_widget'].$args['before_title'].$title.$args['after_title'].$widget_content.$args['after_widget'];
		
	}
	
	
	
	
	
	
}
/*
*	Product category
*/

class Product_category extends WP_Widget{
	
	// to register widget and construct name and widget classes.
	Public function __construct(){
		parent::__construct('Product_category','Maxshop Product Catyegory', array(
			'classname'=>'widget_categories',
			'description' => 'Maxshop Product Catyegory',
		
		));
		
	}
	
	// create widget form
	
	function form($instance){
	
	$title = $instance['title'];
	
	?>
		
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>">Title:
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title');  ?>" type="text" value="<?php echo $title; ?>">
				
			</label>
		</p>
		
	<?php	
		
	}
	// to show result in fornt end;
	function widget($args, $instance ){
		
		$title = ($instance['title']) ? $instance['title'] : 'Category';
		
		global $wp_query;
		
		$is_pro_cat_page = $wp_query->query_vars['product_cat'];
		
		if($is_pro_cat_page){
			$category = get_term_by('name', $is_pro_cat_page, 'product_cat');
			$category_id = $category->term_id;
			$term_children = get_term_children( $category_id, 'product_cat');
			if(count($term_children)){
				$widget_content = '<ul>';
				foreach($term_children as $term_child){
					$term = get_term_by('id', $term_child, 'product_cat');
					
					
					
						$widget_content .= 	'<li><input class="pro_cat" value="'.$term->term_id .'" type="checkbox" /><a href="#" title="'.$term->name.'">'.$term->name.'<span>('.$term->count.')</span></a></li>';
									
								
					
					
				}
				$widget_content .= '</ul>';
				
			}
		
		
		echo $args['before_widget'].$args['before_title'].$title.$args['after_title'].$widget_content.$args['after_widget'];
		}else{
			$terms = get_terms( array(
				'taxonomy' => 'product_cat',
				'hide_empty' => false,
			) );
			
			
		
			if(count($terms)){
				$widget_content = '<ul>';
				foreach($terms as $term){
					
						$widget_content .= 	'<li><input class="pro_cat" value="'.$term->term_id .'" type="checkbox" /><a href="#" title="'.$term->name.'">'.$term->name.'<span>('.$term->count.')</span></a></li>';
						
				}
				$widget_content .= '</ul>';
			}
			
			
			
		echo $args['before_widget'].$args['before_title'].$title.$args['after_title'].$widget_content.$args['after_widget'];	
		}
		
		
	
		
	}
	
	
	
	
	
	
}

/*
*	Price filter
*/

class Price_filter extends WP_Widget{
	
	// to register widget and construct name and widget classes.
	Public function __construct(){
		parent::__construct('Price_filter','Maxshop Price Filter', array(
			'classname'=>'widget_price_filter',
			'description' => 'Maxshop Price Filter',
		
		));
		
	}
	
	// create widget form
	
	function form($instance){
	
	$title = $instance['title'];
	
	?>
		
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>">Title:
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title');  ?>" type="text" value="<?php echo $title; ?>">
				
			</label>
		</p>
		
	<?php	
		
	}
	// to show result in fornt end;
	function widget($args, $instance ){
		
		$title = ($instance['title']) ? $instance['title'] : 'filter by price';
				$widget_content .= '<div class="price-filter">
									<div id="slider-range"></div>
									<div class="price-input">									
										<span id="amount"></span>
										<span id="amount2"></span>
									</div>
									<a href="#" title="filter">Filter</a>
								</div>';
			
			
			
			
		echo $args['before_widget'].$args['before_title'].$title.$args['after_title'].$widget_content.$args['after_widget'];	
		}
		
		
	
		
	
	
	
	
	
	
}



function maxshop_wc_register_widget_(){
	register_widget( 'Product_search' );
	register_widget( 'Product_category' );
	register_widget( 'Price_filter' );
}
