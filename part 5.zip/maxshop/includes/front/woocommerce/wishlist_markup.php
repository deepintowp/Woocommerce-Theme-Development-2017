<?php 

function maxshop_add_wishlist_markup_to_product_layout(){
	?>
<div class="wishlist-box">
	<a href="#"><i class="fa fa-arrows-alt"></i></a>
	<a href="#"><i class="fa fa-heart-o"></i></a>
	<a href="#"><i class="fa fa-search"></i></a>
</div>
	
	<?php 
	
}