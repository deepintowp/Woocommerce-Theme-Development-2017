jQuery(document).ready(function($){
	
	//console.log('i m reday');
	var ProductfilterProcess = function(formdata, action){
		$.ajax({
			url: SearchObj.ajax_url,
			type: 'POST',
			data: {
			action: action,
			data: formdata,
			security: SearchObj.security
				
			},
			success: function(response){
				$('ul.products').html(response);
			},
			 error: function(){
				 console.log('Some problem');
			 }
			
			
		});
		
		
	};
	
	$(document).on('ProductFilter', function(){
			$('ul.products').html('<div class="filter_loading"> <img src="'+SearchObj.theme_uri+'/images/loading_spinner.gif" alt="" /></div>');
		
			var formdata = {
				'minprice' : $('#minprice').val(),
				'maxprice'	 : $('#maxprice').val(),
				'is_archive'	 : $('#is_archive').val(),
				
			};	
			ProductfilterProcess(formdata, 'start_ajax_pro_filter');
	
	});
	
	
	
	$( "#slider-range" ).slider({
	  stop: function( event, ui ) {
		  $(document).trigger('ProductFilter');
	  }
	});
	
	
	
});