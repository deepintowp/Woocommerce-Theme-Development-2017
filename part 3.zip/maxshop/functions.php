<?php 
/*
*	Constant 
*/
define('THEME_PATH', get_template_directory() );
define('THEME_URI', get_template_directory_uri() );





/*
*	includes 
*/

include(THEME_PATH.'/includes/front/enqueue.php');



/*
*	Hooks 
*/
remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
remove_action('woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30);



add_action('wp_enqueue_scripts', 'maxshop_style_and_scripts');

/*
*	Shortcodes
*/


